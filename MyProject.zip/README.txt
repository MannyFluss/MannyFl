Website in progress

Link to Deployed Website:
https://mannyfluss.github.io/MannyFl/